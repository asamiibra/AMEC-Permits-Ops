"""Bounded T6-B application-persistence consumer."""

from .consumer import execute_exact_sqlserver

__all__ = ["execute_exact_sqlserver"]
