# ProposalOps SYN-T6-B Application Persistence Consumer

This bundle is a bounded adapter into the accepted Phase4 persistence seam.
Its only public production entry point is
`execute_exact_sqlserver(database_url, *, candidate_archive, return_archive,
phase5_root)`. It internally verifies the exact T6-A archive/return
identities, safe extraction, manifests, frozen validator, selector set, and
clean exact Phase5 commit/tree before validating the SQLAlchemy URL, creating
an engine, connecting, querying `SELECT 1` plus actual SQL Server properties,
validating SQL Server 2022/non-Azure identity, creating a Session, and
performing persistence.

The consumer never reads source files, invokes a parser, calls an LLM, performs
SMB/DSM access, or creates VerifiedAssertion/projection/protected-action rows.
It emits abstaining classification proposals with `PENDING_REVIEW` status.
The Phase5 evidence hash is an opaque caller-supplied identity; this adapter
binds it to a canonical JSON hash of every accepted `EvidenceEnvelopeIn` field
except the hash field itself. The classification axes use the accepted nested
`classification_proposal` shape and `scope` binding. First-ingestion source
events use the accepted `NEW` event type. The role is mechanically selected
from the exact Phase5 capability matrix as the least-privileged role accepted
for `PHASE4_SOURCE_REVIEW`; no protected promotion/projection call is used.

`qualification.py` is the frozen one-shot runner for the later disposable SQL
Server qualification, including the accepted Alembic baseline, fresh counts,
rollback, successful commit, replay, schema, lineage, and side-effect gates.
SQL Server 2022 execution was not performed in the producer environment because
no local disposable SQL Server mechanism was available.
