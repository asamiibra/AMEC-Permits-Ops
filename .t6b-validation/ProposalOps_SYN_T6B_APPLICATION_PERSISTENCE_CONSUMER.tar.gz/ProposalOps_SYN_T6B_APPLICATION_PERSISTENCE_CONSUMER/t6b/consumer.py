from __future__ import annotations

import hashlib
import importlib
import json
import os
import subprocess
import sys
import tarfile
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable


T6A_CANDIDATE_SHA256 = "8f5f1b64091d3c9b943dc092773b12794eb5af3ee1a7bb7c5eab7e6475f7f6e2"
T6A_CANDIDATE_BYTES = 92139101
T6A_RETURN_SHA256 = "933c43465e56d6c2a1b51a83692c4cba7038118c1c4f54b5dfce504bbba546cc"
T6A_RETURN_BYTES = 1999
T6A_PAYLOAD_SHA256 = "006a59f6f1495b6fb42c4b4eed63d5277630b61b7bf27942670193eb9902676a"
T6A_SCHEMA = "PROPOSALSOPS_T6A_RECOVERY_SANITIZED_RETURN_V4"
T6A_CONTRACT_SHA256 = "b8d96fcb1acfa600706abb48eb41b0b2aa73fc1bf988e79a59a2aad1dec4addd"
PHASE5_COMMIT = "c42e6c449483b0951de0f366d700dbaf7b9e5525"
PHASE5_TREE = "a497c6951064119453d175d1b93d4e59c9029fd0"
MODULE_TRUTH_SHA = "d18ebed191b8f2633d5984ff57ab25803fe19beeb9c73999946abffddb974f2c"
CORPUS_APP_SHA = "387a741b2531afb54398fadbe8aac0d73e2a1ba9aab619e48d5dd5b5d7289908"
SOURCE_SURFACE = "SYNOLOGY_EXTERNAL_EVIDENCE"
SELECTORS = ("T4-TENDERS-01", "T4-TENDERS-08", "T4-TENDERS-12")
FORBIDDEN_PERSISTENCE_TERMS = ("path", "filename", "raw_content", "preview", "password", "secret", "credential", "cookie", "session")


def sha_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def _safe_extract(archive: Path, destination: Path) -> None:
    with tarfile.open(archive, "r:gz") as tf:
        for member in tf.getmembers():
            name = Path(member.name)
            if name.is_absolute() or ".." in name.parts or member.issym() or member.islnk() or not (member.isdir() or member.isfile()):
                raise ValueError("UNSAFE_ARCHIVE_MEMBER")
            target = destination / member.name
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with tf.extractfile(member) as source, target.open("wb") as sink:
                    for chunk in iter(lambda: source.read(1024 * 1024), b""):
                        sink.write(chunk)


def _verify_manifest(root: Path) -> None:
    manifest = root / "MANIFEST.sha256"
    if not manifest.is_file() or manifest.is_symlink():
        raise ValueError("MANIFEST_MISSING")
    seen = set()
    for line in manifest.read_text(encoding="ascii").splitlines():
        if not line.strip():
            continue
        expected, name = line.split("  ", 1)
        if name in seen or Path(name).is_absolute() or ".." in Path(name).parts:
            raise ValueError("MANIFEST_MEMBER_INVALID")
        seen.add(name)
        target = root / name
        if not target.is_file() or target.is_symlink() or sha_file(target) != expected:
            raise ValueError("MANIFEST_MISMATCH")


def _trusted_validator(candidate_parent: Path, contract: dict[str, Any], payload: dict[str, Any]) -> None:
    # The candidate is trusted code. The return extraction directory is never
    # inserted into either sys.path or PYTHONPATH.
    package_name = "ProposalOps_SYN_T6A_RECOVERY_R4"
    old_path = list(sys.path)
    sys.path.insert(0, str(candidate_parent))
    try:
        validator = importlib.import_module(package_name + ".runtime.validate_return")
        validator.validate(payload, T6A_CONTRACT_SHA256, contract, expected_records=3)
    finally:
        sys.path[:] = old_path
        for name in list(sys.modules):
            if name == package_name or name.startswith(package_name + "."):
                del sys.modules[name]


@dataclass(frozen=True)
class _T6BInput:
    candidate_sha256: str
    candidate_bytes: int
    return_sha256: str
    return_bytes: int
    payload_sha256: str
    payload: dict[str, Any]
    contract: dict[str, Any]


def _load_t6a_input(candidate_archive: Path, return_archive: Path) -> _T6BInput:
    candidate_archive, return_archive = Path(candidate_archive), Path(return_archive)
    candidate_sha, return_sha = sha_file(candidate_archive), sha_file(return_archive)
    if candidate_sha != T6A_CANDIDATE_SHA256 or candidate_archive.stat().st_size != T6A_CANDIDATE_BYTES:
        raise ValueError("T6A_CANDIDATE_IDENTITY_MISMATCH")
    if return_sha != T6A_RETURN_SHA256 or return_archive.stat().st_size != T6A_RETURN_BYTES:
        raise ValueError("T6A_RETURN_IDENTITY_MISMATCH")
    with tempfile.TemporaryDirectory(prefix="t6b-input-candidate-") as candidate_td, tempfile.TemporaryDirectory(prefix="t6b-input-return-") as return_td:
        candidate_parent, return_parent = Path(candidate_td), Path(return_td)
        _safe_extract(candidate_archive, candidate_parent)
        _safe_extract(return_archive, return_parent)
        candidate_root = candidate_parent / "ProposalOps_SYN_T6A_RECOVERY_R4"
        if not candidate_root.is_dir() or len(list(candidate_parent.iterdir())) != 1:
            raise ValueError("T6A_CANDIDATE_ROOT_INVALID")
        _verify_manifest(candidate_root)
        return_files = sorted(p.name for p in return_parent.iterdir() if p.is_file())
        if return_files != ["MANIFEST.sha256", "T6A_SANITIZED_RETURN.json"]:
            raise ValueError("T6A_RETURN_TOPOLOGY_INVALID")
        _verify_manifest(return_parent)
        payload_path = return_parent / "T6A_SANITIZED_RETURN.json"
        payload_sha = sha_file(payload_path)
        if payload_sha != T6A_PAYLOAD_SHA256 or payload_path.stat().st_size != 6735:
            raise ValueError("T6A_PAYLOAD_IDENTITY_MISMATCH")
        payload = json.loads(payload_path.read_text(encoding="utf-8"))
        contract_path = candidate_root / "T6A_PRODUCTION_CONTRACT.json"
        if sha_file(contract_path) != T6A_CONTRACT_SHA256:
            raise ValueError("T6A_CONTRACT_IDENTITY_MISMATCH")
        contract = json.loads(contract_path.read_text(encoding="utf-8"))
        if payload.get("schema_version") != T6A_SCHEMA:
            raise ValueError("T6A_SCHEMA_MISMATCH")
        _trusted_validator(candidate_parent, contract, payload)
        if tuple(sorted(record.get("selector_id") for record in payload["records"])) != SELECTORS:
            raise ValueError("T6A_SELECTOR_SET_MISMATCH")
        return _T6BInput(candidate_sha, candidate_archive.stat().st_size, return_sha, return_archive.stat().st_size, payload_sha, payload, contract)


def _git(phase5_root: Path, *args: str) -> str:
    return subprocess.check_output(
        ["git", "-C", str(phase5_root)] + list(args),
        stderr=subprocess.STDOUT,
        text=True,
    ).strip()


def _verify_phase5_root(phase5_root: Path) -> Path:
    supplied = Path(phase5_root)
    if supplied.is_symlink() or not supplied.is_dir():
        raise ValueError("T6B_PHASE5_ROOT_INVALID")
    supplied = supplied.resolve(strict=True)
    try:
        repository_root = Path(_git(supplied, "rev-parse", "--show-toplevel")).resolve(strict=True)
        head = _git(supplied, "rev-parse", "HEAD")
        tree = _git(supplied, "rev-parse", "HEAD^{tree}")
        status = _git(supplied, "status", "--porcelain")
    except (OSError, subprocess.CalledProcessError):
        raise ValueError("T6B_PHASE5_ROOT_NOT_REPOSITORY")
    if repository_root != supplied or head != PHASE5_COMMIT or tree != PHASE5_TREE or status:
        raise ValueError("T6B_PHASE5_IDENTITY_MISMATCH")
    return supplied


def _phase5_api(phase5_root: Path) -> dict[str, Any]:
    trusted_root = _verify_phase5_root(phase5_root)
    trusted = str(trusted_root)
    old_path = list(sys.path)
    for name in list(sys.modules):
        if name == "backend" or name.startswith("backend."):
            del sys.modules[name]
    sys.path.insert(0, trusted)
    try:
        from backend.app.models import Role
        from backend.app.schemas.phase4 import ClassificationEnvelopeIn, EvidenceEnvelopeIn, SourceChangeEventIn
        from backend.app.services.backend_realignment import CAPABILITY_MATRIX, require_capability
        from backend.app.services.phase4 import create_classification_envelope, ingest_evidence_envelope, record_source_event
        loaded = [sys.modules[name] for name in ("backend.app.models", "backend.app.schemas.phase4", "backend.app.services.phase4", "backend.app.services.backend_realignment")]
        for module in loaded:
            origin = getattr(module, "__file__", None)
            try:
                Path(origin).resolve(strict=True).relative_to(trusted_root)
            except (TypeError, ValueError):
                raise RuntimeError("T6B_TRUSTED_PHASE5_ROOT_VIOLATION")
        return {"Role": Role, "SourceChangeEventIn": SourceChangeEventIn, "EvidenceEnvelopeIn": EvidenceEnvelopeIn, "ClassificationEnvelopeIn": ClassificationEnvelopeIn, "record_source_event": record_source_event, "ingest_evidence_envelope": ingest_evidence_envelope, "create_classification_envelope": create_classification_envelope, "CAPABILITY_MATRIX": CAPABILITY_MATRIX, "require_capability": require_capability}
    finally:
        sys.path[:] = old_path


def _selector_spec(bundle: _T6BInput, selector: str) -> tuple[dict[str, Any], dict[str, Any]]:
    record = next((item for item in bundle.payload["records"] if item["selector_id"] == selector), None)
    spec = bundle.contract["selectors"].get(selector)
    if not record or not spec:
        raise ValueError("T6A_SELECTOR_CONTRACT_MISMATCH")
    if record["action_id"] != spec["action_id"] or record["format"] != spec["format"] or record["size"] != spec["expected_size"] or record["expected_mtime_utc"] != spec["expected_mtime_utc"]:
        raise ValueError("T6A_SELECTOR_CONTRACT_MISMATCH")
    if record["source_version_precondition"] != spec["source_version_precondition"] or record["source_version_postcondition"] != record["source_version_precondition"] or record["observed_t6_content_sha256"] != record["expected_t5_content_sha256"]:
        raise ValueError("T6A_SELECTOR_VERSION_MISMATCH")
    return record, spec


def _safe_evidence(record: dict[str, Any]) -> dict[str, Any]:
    evidence = dict(record["evidence"])
    for key in evidence:
        if any(term in key.lower() for term in FORBIDDEN_PERSISTENCE_TERMS):
            raise ValueError("T6B_FORBIDDEN_EVIDENCE_FIELD")
    return evidence


def _ids(bundle: _T6BInput, selector: str) -> dict[str, str]:
    seed = hashlib.sha256((bundle.return_sha256 + ":" + selector).encode("ascii")).hexdigest()
    return {"event_id": "t6b-event-" + seed[:40], "correlation_id": "t6b-correlation-" + seed[:40], "envelope_id": "t6b-envelope-" + seed[:40], "scan": "t6b-" + bundle.return_sha256[:32]}


def _evidence_identity(fields: dict[str, Any]) -> dict[str, Any]:
    # Phase5 treats evidence_envelope_sha256 as an opaque caller-supplied
    # identity. The adapter binds it to the exact accepted EvidenceEnvelopeIn
    # fields, excluding the identity field itself.
    keys = (
        "root_event_id", "source_artifact_id", "source_version_id", "source_version_token",
        "source_surface", "document_intelligence_runtime_version", "runtime_sha256",
        "capability_id", "handler_parser_identity", "metering_json", "warnings_json",
        "content_retention_class", "unsupported_capability_state", "evidence_json",
    )
    if set(fields) - set(keys) - {"evidence_envelope_sha256"} or any(key not in fields for key in keys):
        raise ValueError("T6B_EVIDENCE_FIELDS_INVALID")
    return {key: fields[key] for key in keys}


def _evidence_envelope_sha(fields: dict[str, Any]) -> str:
    return hashlib.sha256(canonical(_evidence_identity(fields))).hexdigest()


def _verify_evidence_envelope_sha(fields: dict[str, Any], expected: str) -> None:
    if _evidence_envelope_sha(fields) != expected:
        raise ValueError("T6B_EVIDENCE_IDENTITY_MISMATCH")


def _derive_execution_role(api: dict[str, Any]) -> Any:
    candidates = []
    for role in api["Role"]:
        try:
            persona = api["require_capability"](role, "PHASE4_SOURCE_REVIEW")
        except Exception:
            continue
        candidates.append((role, persona))
    # This bounded adapter is an internal engineering service. Select only
    # exact Phase5 roles mapped to ENGINEERING, then prefer the canonical
    # responsible-engineer role before equivalent persona aliases.
    candidates = [item for item in candidates if item[1] == "ENGINEERING"]
    if not candidates:
        raise RuntimeError("T6B_NO_ACCEPTED_PHASE5_ENGINEERING_ROLE")
    preference = {"RESPONSIBLE_ENGINEER": 0, "REQUIREMENT_STEWARD": 1, "PERMIT_PREPARER": 2, "FINAL_SUBMITTER": 3}
    return min(candidates, key=lambda item: (len(api["CAPABILITY_MATRIX"][item[1]]), preference.get(item[0].value, 99), item[0].value))[0]


def _consume_validated(db: Any, bundle: _T6BInput, phase5_root: Path, *, failure_after: int = 0) -> list[dict[str, str]]:
    api = _phase5_api(phase5_root)
    role = _derive_execution_role(api)
    results = []
    for index, selector in enumerate(SELECTORS, 1):
        record, spec = _selector_spec(bundle, selector)
        ids = _ids(bundle, selector)
        source_artifact_id = "t6-source-" + spec["source_reference_hash"][:32]
        source = api["SourceChangeEventIn"](
            event_id=ids["event_id"], scan_id_or_observation_group=ids["scan"], source_surface=SOURCE_SURFACE,
            source_artifact_id_or_locator=source_artifact_id, source_version_id=None,
            source_version_token=record["source_version_precondition"], event_type="NEW",
            observed_size=record["physical_input_bytes"], observed_mtime=record["source_post_mtime_utc"],
            origin="T6B_BOUNDED_CONSUMER", correlation_id=ids["correlation_id"], observed_at=record["observed_at_utc"],
            stability_state="STABLE", observation_count=2, stability_window_seconds=0,
            content_identity_proof={"source_reference_hash": spec["source_reference_hash"], "content_sha256": record["observed_t6_content_sha256"], "size": record["physical_input_bytes"], "expected_mtime_utc": record["expected_mtime_utc"], "source_version_precondition": record["source_version_precondition"]},
        )
        event = api["record_source_event"](db, source, role)
        if failure_after and index == failure_after:
            raise RuntimeError("T6B_INJECTED_PRECOMMIT_FAILURE")
        evidence = _safe_evidence(record)
        evidence_fields = dict(
            root_event_id=event.id, source_artifact_id=source_artifact_id, source_version_id=None,
            source_version_token=record["source_version_precondition"], source_surface=SOURCE_SURFACE,
            document_intelligence_runtime_version="AMEC_MODERN_BOUNDED_STRUCTURE_PARSER@1.2.0",
            runtime_sha256=bundle.candidate_sha256, capability_id="PHASE4_SOURCE_REVIEW", handler_parser_identity=evidence["identity"],
            metering_json={"physical_input_bytes": record["physical_input_bytes"], "parser_output_bytes": evidence["parser_output_bytes"]}, warnings_json=[],
            content_retention_class="METADATA_ONLY", unsupported_capability_state=None, evidence_json=evidence,
        )
        evidence_fields["evidence_envelope_sha256"] = _evidence_envelope_sha(evidence_fields)
        _verify_evidence_envelope_sha(evidence_fields, evidence_fields["evidence_envelope_sha256"])
        envelope = api["EvidenceEnvelopeIn"](**evidence_fields)
        persisted_evidence = api["ingest_evidence_envelope"](db, envelope, role)
        axes = {"scope": {"scope_type": "AMEC", "scope_id": source_artifact_id}, "classification_proposal": {"document_type": "UNRESOLVED", "discipline": "UNRESOLVED", "disposition": "NEEDS_REVIEW", "review_reason": "INSUFFICIENT_REAL_SEMANTIC_EVIDENCE", "review_required": True, "classifier_authority": "PROPOSAL_ONLY", "auto_promotion": False}, "bounded_evidence": {"evidence_envelope_sha256": persisted_evidence.evidence_envelope_sha256, "source_reference_hash": spec["source_reference_hash"], "format": record["format"], "size": record["physical_input_bytes"], "observed_t6_content_sha256": record["observed_t6_content_sha256"]}}
        classification = api["ClassificationEnvelopeIn"](
            envelope_id=ids["envelope_id"], root_event_id=event.id, document_version_id=None, source_mode=SOURCE_SURFACE,
            classifier_version="t6b-abstain-v1", rules_version="t6b-bounded-evidence-v1", taxonomy_revision="phase4-abstain-v1",
            module_truth_contract_sha=MODULE_TRUTH_SHA, corpus_app_contract_sha=CORPUS_APP_SHA, axes_json=axes,
        )
        item = api["create_classification_envelope"](db, classification, role)
        results.append({"selector_id": selector, "source_event_id": event.id, "evidence_envelope_id": persisted_evidence.id, "classification_envelope_id": item.id, "correlation_id": ids["correlation_id"]})
    return results


def _consume_exact_and_commit(db: Any, bundle: _T6BInput, phase5_root: Path) -> list[dict[str, str]]:
    with db.begin():
        return _consume_validated(db, bundle, phase5_root)


def _make_engine(database_url: str) -> Any:
    from sqlalchemy import create_engine
    return create_engine(database_url, future=True)


def execute_exact_sqlserver(database_url: str, *, candidate_archive: Path, return_archive: Path, phase5_root: Path) -> list[dict[str, str]]:
    # This is the sole public production path. All artifact and Phase5 gates
    # precede URL validation, engine creation, connection, and Session setup.
    phase5_root = _verify_phase5_root(phase5_root)
    bundle = _load_t6a_input(candidate_archive, return_archive)
    from .sqlserver_gate import query_server_properties, validate_local_sqlalchemy_url, validate_server_properties
    validate_local_sqlalchemy_url(database_url)
    engine = _make_engine(database_url)
    try:
        with engine.connect() as connection:
            properties = query_server_properties(connection)
        from sqlalchemy.orm import sessionmaker
        validate_server_properties(properties)
        SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
        with SessionLocal() as db:
            return _consume_exact_and_commit(db, bundle, phase5_root)
    finally:
        engine.dispose()
