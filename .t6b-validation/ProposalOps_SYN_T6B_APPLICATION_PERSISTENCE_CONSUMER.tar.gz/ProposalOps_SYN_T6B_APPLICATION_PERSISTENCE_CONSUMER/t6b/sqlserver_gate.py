from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import text
from sqlalchemy.engine import make_url


@dataclass(frozen=True)
class SqlServerProperties:
    product_major_version: int
    engine_edition: int
    product_version: str


def validate_local_sqlalchemy_url(database_url: str) -> None:
    try:
        parsed = make_url(database_url)
    except Exception:
        raise ValueError("SQLSERVER_URL_INVALID")
    if parsed.drivername != "mssql+pyodbc":
        raise ValueError("SQLSERVER_DRIVER_NOT_ALLOWED")
    if parsed.host not in {"localhost", "127.0.0.1"}:
        raise ValueError("SQLSERVER_HOST_NOT_LOCAL")
    if not parsed.database:
        raise ValueError("SQLSERVER_DATABASE_REQUIRED")


def validate_server_properties(properties: SqlServerProperties) -> None:
    if properties.product_major_version != 16:
        raise ValueError("SQLSERVER_PRODUCT_MAJOR_VERSION_NOT_16")
    # SQL Server engine edition 5 is Azure SQL Database and 8 is Azure
    # Managed Instance; both are outside the disposable local qualification.
    if properties.engine_edition in {5, 8}:
        raise ValueError("AZURE_SQL_ENGINE_NOT_ALLOWED")


def query_server_properties(connection: object) -> SqlServerProperties:
    """Observe the connected server; caller-supplied properties are invalid."""
    probe = connection.execute(text("SELECT 1"))
    if probe.scalar_one() != 1:
        raise ValueError("SQLSERVER_SELECT_1_FAILED")
    row = connection.execute(text(
        "SELECT SERVERPROPERTY('ProductMajorVersion'), "
        "SERVERPROPERTY('EngineEdition'), SERVERPROPERTY('ProductVersion')"
    )).one()
    try:
        properties = SqlServerProperties(
            product_major_version=int(row[0]),
            engine_edition=int(row[1]),
            product_version=str(row[2]),
        )
    except (TypeError, ValueError, IndexError) as exc:
        raise ValueError("SQLSERVER_PROPERTIES_INVALID") from exc
    if not properties.product_version:
        raise ValueError("SQLSERVER_PRODUCT_VERSION_REQUIRED")
    validate_server_properties(properties)
    return properties
