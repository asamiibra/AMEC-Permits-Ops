"""Frozen, one-shot SQL Server 2022 qualification runner for T6-B.

This module is intentionally prepared without opening a database.  At run
time it performs the exact preflight, accepted Alembic baseline, fresh-run
counts, rollback, success, replay, schema, lineage, and zero-side-effect
assertions against one disposable local SQL Server.
"""

from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import json
import os
import platform
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

from sqlalchemy import select, text
from sqlalchemy.orm import Session, sessionmaker

from . import consumer
from .sqlserver_gate import query_server_properties, validate_local_sqlalchemy_url


T6B_CONSUMER_IMPLEMENTATION_SHA256 = "6689959f300461e2b7eba669728c59c02251362d36bba4e853bdcfbd9ef32778"
T6B_CONSUMER_IMPLEMENTATION_BYTES = 18389
T6B_SQL_GATE_IMPLEMENTATION_SHA256 = "0f3b7552445754cbb2af195be6e26848562a176756f63bc2ceee10681aff2834"
T6B_SQL_GATE_IMPLEMENTATION_BYTES = 2133
T6A_CANDIDATE_SHA256 = consumer.T6A_CANDIDATE_SHA256
T6A_RETURN_SHA256 = consumer.T6A_RETURN_SHA256
T6A_CONTRACT_SHA256 = consumer.T6A_CONTRACT_SHA256
PHASE5_COMMIT = consumer.PHASE5_COMMIT
PHASE5_TREE = consumer.PHASE5_TREE
EXPECTED_ALEMBIC_HEAD = "baseline_phase4_v36_azure_sql"
REQUIRED_COUNTS = {
    "source_events": 3,
    "evidence_envelopes": 3,
    "classification_envelopes": 3,
    "pending_review": 3,
}


def _canonical(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def _sha_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json(path: Path, value: Any) -> None:
    temporary = path.with_name("." + path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        stream.write(json.dumps(value, sort_keys=True, indent=2) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)
    directory_fd = os.open(str(path.parent), os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def _verify_frozen_implementation_binding() -> None:
    consumer_path = Path(consumer.__file__).resolve(strict=True)
    gate_path = consumer_path.with_name("sqlserver_gate.py")
    if _sha_file(consumer_path) != T6B_CONSUMER_IMPLEMENTATION_SHA256 or consumer_path.stat().st_size != T6B_CONSUMER_IMPLEMENTATION_BYTES:
        raise RuntimeError("T6B_CONSUMER_IMPLEMENTATION_BINDING_MISMATCH")
    if _sha_file(gate_path) != T6B_SQL_GATE_IMPLEMENTATION_SHA256 or gate_path.stat().st_size != T6B_SQL_GATE_IMPLEMENTATION_BYTES:
        raise RuntimeError("T6B_SQL_GATE_IMPLEMENTATION_BINDING_MISMATCH")


def _reflection_source_audit() -> dict[str, int]:
    tree = ast.parse(Path(__file__).read_text(encoding="utf-8"), filename=str(Path(__file__)))
    counts = {
        "SQLALCHEMY_INSPECT_CALL_COUNT": 0,
        "METADATA_REFLECT_CALL_COUNT": 0,
        "GET_COLUMNS_CALL_COUNT": 0,
        "GET_UNIQUE_CONSTRAINTS_CALL_COUNT": 0,
    }
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute):
            continue
        method = node.func.attr
        if method == "inspect":
            counts["SQLALCHEMY_INSPECT_CALL_COUNT"] += 1
        elif method == "reflect":
            counts["METADATA_REFLECT_CALL_COUNT"] += 1
        elif method == "get_columns":
            counts["GET_COLUMNS_CALL_COUNT"] += 1
        elif method == "get_unique_constraints":
            counts["GET_UNIQUE_CONSTRAINTS_CALL_COUNT"] += 1
    if any(counts.values()):
        raise RuntimeError("MSSQL_REFLECTION_SOURCE_AUDIT_FAILED")
    return counts


_CATALOG_QUERIES = {
    "tables": {
        "source_function": "_schema_document",
        "catalog_objects": ["sys.tables", "sys.schemas"],
        "expected_result_keys": ["schema_name", "table_name"],
        "statement": """
            SELECT CONVERT(varchar(128), s.name) AS [schema_name],
                   CONVERT(varchar(128), t.name) AS [table_name]
            FROM sys.tables AS t
            JOIN sys.schemas AS s ON s.schema_id = t.schema_id
            WHERE t.is_ms_shipped = CONVERT(bit, 0)
            ORDER BY CONVERT(varchar(128), s.name), CONVERT(varchar(128), t.name)
        """,
    },
    "columns": {
        "source_function": "_schema_document",
        "catalog_objects": ["sys.columns", "sys.tables", "sys.schemas", "sys.types"],
        "expected_result_keys": ["schema_name", "table_name", "ordinal", "column_name", "sql_type_name", "max_length", "precision", "scale", "nullable", "identity", "computed"],
        "statement": """
            SELECT CONVERT(varchar(128), s.name) AS [schema_name],
                   CONVERT(varchar(128), t.name) AS [table_name],
                   CONVERT(int, c.column_id) AS [ordinal],
                   CONVERT(varchar(128), c.name) AS [column_name],
                   CONVERT(varchar(128), ty.name) AS [sql_type_name],
                   CONVERT(int, c.max_length) AS [max_length],
                   CONVERT(int, c.precision) AS [precision],
                   CONVERT(int, c.scale) AS [scale],
                   CONVERT(int, c.is_nullable) AS [nullable],
                   CONVERT(int, c.is_identity) AS [identity],
                   CONVERT(int, c.is_computed) AS [computed]
            FROM sys.columns AS c
            JOIN sys.tables AS t ON t.object_id = c.object_id
            JOIN sys.schemas AS s ON s.schema_id = t.schema_id
            JOIN sys.types AS ty ON ty.user_type_id = c.user_type_id
            WHERE t.is_ms_shipped = CONVERT(bit, 0)
            ORDER BY CONVERT(varchar(128), s.name), CONVERT(varchar(128), t.name), CONVERT(int, c.column_id)
        """,
    },
    "keys": {
        "source_function": "_schema_document",
        "catalog_objects": ["sys.indexes", "sys.tables", "sys.schemas", "sys.index_columns", "sys.columns"],
        "expected_result_keys": ["schema_name", "table_name", "identity_name", "kind", "is_unique", "is_primary_key", "key_ordinal", "column_name"],
        "statement": """
            SELECT CONVERT(varchar(128), s.name) AS [schema_name],
                   CONVERT(varchar(128), t.name) AS [table_name],
                   CONVERT(varchar(256), i.name) AS [identity_name],
                   CONVERT(varchar(32), CASE WHEN i.is_primary_key = CONVERT(bit, 1) THEN 'PRIMARY_KEY' WHEN i.is_unique_constraint = CONVERT(bit, 1) THEN 'UNIQUE_CONSTRAINT' ELSE 'UNIQUE_INDEX' END) AS [kind],
                   CONVERT(int, i.is_unique) AS [is_unique],
                   CONVERT(int, i.is_primary_key) AS [is_primary_key],
                   CONVERT(int, ic.key_ordinal) AS [key_ordinal],
                   CONVERT(varchar(128), c.name) AS [column_name]
            FROM sys.indexes AS i
            JOIN sys.tables AS t ON t.object_id = i.object_id
            JOIN sys.schemas AS s ON s.schema_id = t.schema_id
            JOIN sys.index_columns AS ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
            JOIN sys.columns AS c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
            WHERE t.is_ms_shipped = CONVERT(bit, 0)
              AND i.index_id > CONVERT(int, 0)
              AND i.is_hypothetical = CONVERT(bit, 0)
              AND i.is_unique = CONVERT(bit, 1)
              AND ic.key_ordinal > CONVERT(int, 0)
            ORDER BY CONVERT(varchar(128), s.name), CONVERT(varchar(128), t.name), CONVERT(varchar(256), i.name), CONVERT(int, ic.key_ordinal)
        """,
    },
    "indexes": {
        "source_function": "_schema_document",
        "catalog_objects": ["sys.indexes", "sys.tables", "sys.schemas", "sys.index_columns", "sys.columns"],
        "expected_result_keys": ["schema_name", "table_name", "identity_name", "is_unique", "is_primary_key", "is_unique_constraint", "key_ordinal", "index_column_ordinal", "is_included_column", "column_name"],
        "statement": """
            SELECT CONVERT(varchar(128), s.name) AS [schema_name],
                   CONVERT(varchar(128), t.name) AS [table_name],
                   CONVERT(varchar(256), i.name) AS [identity_name],
                   CONVERT(int, i.is_unique) AS [is_unique],
                   CONVERT(int, i.is_primary_key) AS [is_primary_key],
                   CONVERT(int, i.is_unique_constraint) AS [is_unique_constraint],
                   CONVERT(int, ic.key_ordinal) AS [key_ordinal],
                   CONVERT(int, ic.index_column_id) AS [index_column_ordinal],
                   CONVERT(int, ic.is_included_column) AS [is_included_column],
                   CONVERT(varchar(128), c.name) AS [column_name]
            FROM sys.indexes AS i
            JOIN sys.tables AS t ON t.object_id = i.object_id
            JOIN sys.schemas AS s ON s.schema_id = t.schema_id
            JOIN sys.index_columns AS ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id
            JOIN sys.columns AS c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
            WHERE t.is_ms_shipped = CONVERT(bit, 0)
              AND i.index_id > CONVERT(int, 0)
              AND i.is_hypothetical = CONVERT(bit, 0)
            ORDER BY CONVERT(varchar(128), s.name), CONVERT(varchar(128), t.name), CONVERT(varchar(256), i.name), CONVERT(int, ic.index_column_id)
        """,
    },
    "foreign_keys": {
        "source_function": "_schema_document",
        "catalog_objects": ["sys.foreign_keys", "sys.foreign_key_columns", "sys.tables", "sys.schemas", "sys.columns"],
        "expected_result_keys": ["schema_name", "table_name", "identity_name", "column_name", "referred_schema", "referred_table", "referred_column", "column_ordinal", "ondelete", "onupdate"],
        "statement": """
            SELECT CONVERT(varchar(128), ss.name) AS [schema_name],
                   CONVERT(varchar(128), st.name) AS [table_name],
                   CONVERT(varchar(256), fk.name) AS [identity_name],
                   CONVERT(varchar(128), sc.name) AS [column_name],
                   CONVERT(varchar(128), rs.name) AS [referred_schema],
                   CONVERT(varchar(128), rt.name) AS [referred_table],
                   CONVERT(varchar(128), rc.name) AS [referred_column],
                   CONVERT(int, fkc.constraint_column_id) AS [column_ordinal],
                   CONVERT(varchar(32), fk.delete_referential_action_desc) AS [ondelete],
                   CONVERT(varchar(32), fk.update_referential_action_desc) AS [onupdate]
            FROM sys.foreign_keys AS fk
            JOIN sys.foreign_key_columns AS fkc ON fkc.constraint_object_id = fk.object_id
            JOIN sys.tables AS st ON st.object_id = fkc.parent_object_id
            JOIN sys.schemas AS ss ON ss.schema_id = st.schema_id
            JOIN sys.columns AS sc ON sc.object_id = fkc.parent_object_id AND sc.column_id = fkc.parent_column_id
            JOIN sys.tables AS rt ON rt.object_id = fkc.referenced_object_id
            JOIN sys.schemas AS rs ON rs.schema_id = rt.schema_id
            JOIN sys.columns AS rc ON rc.object_id = fkc.referenced_object_id AND rc.column_id = fkc.referenced_column_id
            WHERE st.is_ms_shipped = CONVERT(bit, 0)
            ORDER BY CONVERT(varchar(128), ss.name), CONVERT(varchar(128), st.name), CONVERT(varchar(256), fk.name), CONVERT(int, fkc.constraint_column_id)
        """,
    },
    "runtime_table_count": {
        "source_function": "_reflection_runtime_probe",
        "catalog_objects": ["sys.tables"],
        "expected_result_keys": ["table_count"],
        "statement": """
            SELECT CONVERT(int, COUNT(*)) AS [table_count]
            FROM sys.tables AS t
            WHERE t.is_ms_shipped = CONVERT(bit, 0)
        """,
    },
    "defaults": {
        "source_function": "_schema_document",
        "catalog_objects": ["sys.default_constraints", "sys.tables", "sys.schemas", "sys.columns"],
        "expected_result_keys": ["schema_name", "table_name", "identity_name", "column_name", "predicate"],
        "statement": """
            SELECT CONVERT(varchar(128), s.name) AS [schema_name],
                   CONVERT(varchar(128), t.name) AS [table_name],
                   CONVERT(varchar(256), dc.name) AS [identity_name],
                   CONVERT(varchar(128), c.name) AS [column_name],
                   CONVERT(varchar(max), dc.definition) AS [predicate]
            FROM sys.default_constraints AS dc
            JOIN sys.tables AS t ON t.object_id = dc.parent_object_id
            JOIN sys.schemas AS s ON s.schema_id = t.schema_id
            JOIN sys.columns AS c ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
            WHERE t.is_ms_shipped = CONVERT(bit, 0)
            ORDER BY CONVERT(varchar(128), s.name), CONVERT(varchar(128), t.name), CONVERT(varchar(256), dc.name)
        """,
    },
    "checks": {
        "source_function": "_schema_document",
        "catalog_objects": ["sys.check_constraints", "sys.tables", "sys.schemas"],
        "expected_result_keys": ["schema_name", "table_name", "identity_name", "column_name", "predicate"],
        "statement": """
            SELECT CONVERT(varchar(128), s.name) AS [schema_name],
                   CONVERT(varchar(128), t.name) AS [table_name],
                   CONVERT(varchar(256), cc.name) AS [identity_name],
                   CONVERT(varchar(128), NULL) AS [column_name],
                   CONVERT(varchar(max), cc.definition) AS [predicate]
            FROM sys.check_constraints AS cc
            JOIN sys.tables AS t ON t.object_id = cc.parent_object_id
            JOIN sys.schemas AS s ON s.schema_id = t.schema_id
            WHERE t.is_ms_shipped = CONVERT(bit, 0)
            ORDER BY CONVERT(varchar(128), s.name), CONVERT(varchar(128), t.name), CONVERT(varchar(256), cc.name)
        """,
    },
}

_CATALOG_RESERVED_ALIASES = {"identity", "precision", "scale", "key", "constraint", "index", "schema", "table", "column", "order"}


def _catalog_sql_alias_audit() -> dict[str, Any]:
    queries = []
    unquoted = []
    reserved_collisions = []
    expected_mismatches = []
    for query_id, spec in _CATALOG_QUERIES.items():
        select_list = spec["statement"].split("FROM", 1)[0]
        select_list = select_list.split("SELECT", 1)[1]
        aliases = []
        quoted_aliases = []
        unquoted_aliases = []
        for match in re.finditer(r"\bAS\s+(\[[^\]]+\]|[A-Za-z_][A-Za-z0-9_]*)", select_list, flags=re.IGNORECASE):
            token = match.group(1)
            alias = token[1:-1] if token.startswith("[") else token
            aliases.append(alias)
            if token.startswith("["):
                quoted_aliases.append(alias)
            else:
                unquoted_aliases.append(alias)
                unquoted.append({"query_id": query_id, "alias": alias})
                if alias.lower() in _CATALOG_RESERVED_ALIASES:
                    reserved_collisions.append({"query_id": query_id, "alias": alias})
        expected = list(spec["expected_result_keys"])
        if aliases != expected:
            expected_mismatches.append({"query_id": query_id, "expected": expected, "actual": aliases})
        queries.append({"query_id": query_id, "source_function": spec["source_function"], "catalog_objects": list(spec["catalog_objects"]), "select_output_aliases": aliases, "quoted_output_aliases": quoted_aliases, "unquoted_output_aliases": unquoted_aliases, "expected_result_keys": expected})
    return {
        "queries": queries,
        "catalog_query_count": len(queries),
        "catalog_select_output_alias_count": sum(len(item["select_output_aliases"]) for item in queries),
        "catalog_unquoted_output_alias_count": len(unquoted),
        "catalog_reserved_alias_collision_count": len(reserved_collisions),
        "catalog_expected_result_key_mismatch_count": len(expected_mismatches),
        "unquoted_aliases": unquoted,
        "reserved_alias_collisions": reserved_collisions,
        "expected_result_key_mismatches": expected_mismatches,
    }


def _catalog_rows(connection: Any, query_id: str) -> list[dict[str, Any]]:
    spec = _CATALOG_QUERIES[query_id]
    evidence = connection.info.setdefault("t6b_catalog_query_evidence", [])
    try:
        result = connection.exec_driver_sql(spec["statement"])
        returned_keys = [str(key) for key in result.keys()]
        expected_keys = list(spec["expected_result_keys"])
        if returned_keys != expected_keys:
            raise RuntimeError("CATALOG_RESULT_KEY_MISMATCH:" + query_id)
        rows = [dict(row) for row in result.mappings().all()]
        evidence.append({"query_id": query_id, "execution": "PASS", "row_count": len(rows), "returned_column_keys": returned_keys})
        return rows
    except Exception:
        evidence.append({"query_id": query_id, "execution": "FAIL", "row_count": None, "returned_column_keys": []})
        raise


def _schema_document(connection: Any) -> dict[str, Any]:
    table_rows = _catalog_rows(connection, "tables")
    column_rows = _catalog_rows(connection, "columns")
    key_rows = _catalog_rows(connection, "keys")
    index_rows = _catalog_rows(connection, "indexes")
    foreign_rows = _catalog_rows(connection, "foreign_keys")
    default_rows = _catalog_rows(connection, "defaults")
    check_rows = _catalog_rows(connection, "checks")
    def same(row: dict[str, Any], schema: str, table: str) -> bool:
        return row["schema_name"] == schema and row["table_name"] == table
    tables = []
    for table_row in table_rows:
        schema, table = str(table_row["schema_name"]), str(table_row["table_name"])
        columns = [{key: (str(row[key]) if key in {"column_name", "sql_type_name"} else int(row[key])) for key in ("ordinal", "column_name", "sql_type_name", "max_length", "precision", "scale", "nullable", "identity", "computed")} for row in column_rows if same(row, schema, table)]
        scoped_keys = [row for row in key_rows if same(row, schema, table)]
        primary_groups: dict[str, list[dict[str, Any]]] = {}
        unique_groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
        for row in scoped_keys:
            if row["kind"] == "PRIMARY_KEY": primary_groups.setdefault(str(row["identity_name"]), []).append(row)
            else: unique_groups.setdefault((str(row["identity_name"]), str(row["kind"])), []).append(row)
        primary = next(iter(sorted(primary_groups.items())), (None, []))
        primary_key = {"name": primary[0], "constrained_columns": [str(row["column_name"]) for row in sorted(primary[1], key=lambda r: int(r["key_ordinal"]))]}
        unique_constraints = [{"name": name, "kind": kind, "column_names": [str(row["column_name"]) for row in sorted(rows, key=lambda r: int(r["key_ordinal"]))]} for (name, kind), rows in sorted(unique_groups.items())]
        scoped_indexes = [row for row in index_rows if same(row, schema, table)]
        index_groups: dict[str, list[dict[str, Any]]] = {}
        for row in scoped_indexes: index_groups.setdefault(str(row["identity_name"]), []).append(row)
        indexes = []
        for name, rows in sorted(index_groups.items()):
            ordered = sorted(rows, key=lambda r: (int(r["is_included_column"]), int(r["key_ordinal"]) if int(r["key_ordinal"]) else 2147483647, int(r["index_column_ordinal"])))
            indexes.append({"name": name, "column_names": [str(row["column_name"]) for row in ordered if int(row["is_included_column"]) == 0], "included_columns": [str(row["column_name"]) for row in ordered if int(row["is_included_column"]) == 1], "unique": int(rows[0]["is_unique"]), "primary_key": int(rows[0]["is_primary_key"]), "unique_constraint": int(rows[0]["is_unique_constraint"])})
        scoped_foreign = [row for row in foreign_rows if same(row, schema, table)]
        foreign_groups: dict[str, list[dict[str, Any]]] = {}
        for row in scoped_foreign: foreign_groups.setdefault(str(row["identity_name"]), []).append(row)
        foreign_keys = []
        for name, rows in sorted(foreign_groups.items()):
            rows.sort(key=lambda r: int(r["column_ordinal"]))
            foreign_keys.append({"name": name, "constrained_columns": [str(row["column_name"]) for row in rows], "referred_schema": str(rows[0]["referred_schema"]), "referred_table": str(rows[0]["referred_table"]), "referred_columns": [str(row["referred_column"]) for row in rows], "ondelete": str(rows[0]["ondelete"]), "onupdate": str(rows[0]["onupdate"])})
        defaults = [{"name": str(row["identity_name"]), "column_name": str(row["column_name"]), "predicate": str(row["predicate"])} for row in default_rows if same(row, schema, table)]
        checks = [{"name": str(row["identity_name"]), "predicate": str(row["predicate"])} for row in check_rows if same(row, schema, table)]
        tables.append({"schema": schema, "table": table, "columns": columns, "primary_key": primary_key, "foreign_keys": foreign_keys, "unique_constraints": unique_constraints, "indexes": indexes, "defaults": sorted(defaults, key=lambda row: (row["name"], row["column_name"])), "check_constraints": sorted(checks, key=lambda row: (row["name"], row["predicate"]))})
    return {"tables": tables}


def _schema_fingerprint(connection: Any) -> tuple[dict[str, Any], str]:
    document = _schema_document(connection)
    return document, hashlib.sha256(_canonical(document)).hexdigest()


def _table_key(schema: str, table: str) -> str:
    return schema + "." + table


def _all_table_counts(connection: Any) -> dict[str, int]:
    counts = {}
    preparer = connection.dialect.identifier_preparer
    for row in _catalog_rows(connection, "tables"):
        schema = str(row["schema_name"])
        table = str(row["table_name"])
        qualified = preparer.quote_schema(schema) + "." + preparer.quote(table)
        counts[_table_key(schema, table)] = int(connection.exec_driver_sql("SELECT COUNT_BIG(*) FROM " + qualified).scalar_one())
    return dict(sorted(counts.items()))


def _network_report() -> dict[str, Any]:
    if platform.system() != "Linux" or platform.machine().lower() not in {"x86_64", "amd64"}:
        raise RuntimeError("T6B_NATIVE_LINUX_X86_64_REQUIRED")
    route_file = Path("/proc/net/route")
    if not route_file.is_file() or not os.access(str(route_file), os.R_OK):
        raise RuntimeError("T6B_PROC_NET_ROUTE_UNAVAILABLE")
    routes = []
    for line in route_file.read_text(encoding="ascii", errors="strict").splitlines()[1:]:
        fields = line.split()
        if len(fields) >= 4:
            routes.append({"interface": fields[0], "destination": fields[1], "flags": fields[3]})
    default_routes = [item for item in routes if item["destination"] == "00000000" and item["interface"] != "lo"]
    non_loopback = [item for item in routes if item["interface"] != "lo"]
    sockets = {path: Path(path).exists() for path in ("/var/run/docker.sock", "/run/docker.sock")}
    return {"runtime_os": platform.system(), "runtime_arch": platform.machine().lower(), "routes": routes, "default_route_count": len(default_routes), "external_nonloopback_route_count": len(non_loopback), "external_network_route_available": bool(default_routes or non_loopback), "docker_socket_paths_present": sockets, "docker_socket_present": any(sockets.values())}


def _require_network_isolation(report: dict[str, Any]) -> None:
    if report["default_route_count"] != 0 or report["external_nonloopback_route_count"] != 0 or report["docker_socket_present"]:
        raise RuntimeError("T6B_NETWORK_ISOLATION_NOT_PROVEN")


def _reflection_runtime_probe(connection: Any) -> None:
    rows = _catalog_rows(connection, "runtime_table_count")
    if not rows or int(rows[0]["table_count"]) == 0:
        raise RuntimeError("MSSQL_REFLECTION_RUNTIME_NO_TABLES")


def _assert_schema_mutation_sensitivity() -> None:
    document = {"tables": [{
        "schema": "dbo", "table": "sample", "columns": [{"ordinal": 1, "column_name": "id", "sql_type_name": "int", "max_length": 4, "precision": 10, "scale": 0, "nullable": 0, "identity": 1, "computed": 0}],
        "primary_key": {"name": "pk_sample", "constrained_columns": ["id"]},
        "foreign_keys": [{"name": "fk_sample_parent", "constrained_columns": ["id"], "referred_schema": "dbo", "referred_table": "parent", "referred_columns": ["id"], "ondelete": "NO_ACTION", "onupdate": "NO_ACTION"}],
        "unique_constraints": [{"name": "uq_sample_id", "kind": "UNIQUE_CONSTRAINT", "column_names": ["id"]}],
        "indexes": [{"name": "ix_sample_id", "column_names": ["id"], "unique": 0, "primary_key": 0, "unique_constraint": 0}],
        "defaults": [{"name": "df_sample_id", "column_name": "id", "predicate": "(0)"}],
        "check_constraints": [{"name": "ck_sample_id", "predicate": "([id] >= (0))"}],
    }]}
    original = hashlib.sha256(_canonical(document)).hexdigest()
    mutations = {
        "COLUMN_ADD_MUTATION_DETECTED": ("columns", document["tables"][0]["columns"] + [{"ordinal": 2, "column_name": "added", "sql_type_name": "int", "max_length": 4, "precision": 10, "scale": 0, "nullable": 1, "identity": 0, "computed": 0}]),
        "COLUMN_REMOVE_MUTATION_DETECTED": ("columns", []),
        "COLUMN_TYPE_MUTATION_DETECTED": ("columns", [{**document["tables"][0]["columns"][0], "sql_type_name": "bigint"}]),
        "COLUMN_LENGTH_MUTATION_DETECTED": ("columns", [{**document["tables"][0]["columns"][0], "max_length": 8}]),
        "COLUMN_PRECISION_MUTATION_DETECTED": ("columns", [{**document["tables"][0]["columns"][0], "precision": 12}]),
        "COLUMN_SCALE_MUTATION_DETECTED": ("columns", [{**document["tables"][0]["columns"][0], "scale": 2}]),
        "NULLABILITY_MUTATION_DETECTED": ("columns", [{**document["tables"][0]["columns"][0], "nullable": 1}]),
        "IDENTITY_MUTATION_DETECTED": ("columns", [{**document["tables"][0]["columns"][0], "identity": 0}]),
        "COMPUTED_MUTATION_DETECTED": ("columns", [{**document["tables"][0]["columns"][0], "computed": 1}]),
        "TABLE_NAME_MUTATION_DETECTED": ("table", "other_table"),
        "SCHEMA_NAME_MUTATION_DETECTED": ("schema", "other_schema"),
        "PRIMARY_KEY_MUTATION_DETECTED": ("primary_key", {"name": "pk_sample_changed", "constrained_columns": ["id"]}),
        "UNIQUE_KEY_MUTATION_DETECTED": ("unique_constraints", [{"name": "uq_sample_id_changed", "kind": "UNIQUE_CONSTRAINT", "column_names": ["id"]}]),
        "FOREIGN_KEY_MUTATION_DETECTED": ("foreign_keys", [{"name": "fk_sample_parent", "constrained_columns": ["id"], "referred_schema": "dbo", "referred_table": "other_parent", "referred_columns": ["id"], "ondelete": "NO_ACTION", "onupdate": "NO_ACTION"}]),
        "DEFAULT_MUTATION_DETECTED": ("defaults", [{"name": "df_sample_id", "column_name": "id", "predicate": "(1)"}]),
        "CHECK_MUTATION_DETECTED": ("check_constraints", [{"name": "ck_sample_id", "predicate": "([id] > (0))"}]),
    }
    for label, (field, mutation) in mutations.items():
        altered = copy.deepcopy(document)
        altered["tables"][0][field] = mutation
        if hashlib.sha256(_canonical(altered)).hexdigest() == original:
            raise AssertionError("SCHEMA_FINGERPRINT_MUTATION_NOT_SENSITIVE:" + field)
    return {label: True for label in mutations}


def _schema_document_semantics_audit() -> dict[str, bool]:
    matrix = _assert_schema_mutation_sensitivity()
    return {"SCHEMA_FINGERPRINT_MUTATION_MATRIX_PASS": bool(matrix), "SCHEMA_FINGERPRINT_MUTATION_COUNT": len(matrix)}


def _counts(session: Session, models: dict[str, Any]) -> dict[str, int]:
    source = models["Phase4SourceChangeEvent"]
    evidence = models["Phase4DocumentEvidenceEnvelope"]
    classification = models["Phase4ClassificationEnvelope"]
    return {
        "source_events": session.query(source).count(),
        "evidence_envelopes": session.query(evidence).count(),
        "classification_envelopes": session.query(classification).count(),
        "pending_review": session.query(classification).filter(classification.status == "PENDING_REVIEW").count(),
    }


def _baseline(database_url: str, phase5_root: Path) -> None:
    environment = os.environ.copy()
    environment["DATABASE_URL"] = database_url
    environment["APP_ENV"] = "TEST"
    environment["SYNTHETIC_ONLY"] = "true"
    environment["REAL_DATA_ALLOWED"] = "false"
    subprocess.run(
        [sys.executable, "-m", "alembic", "-c", str(phase5_root / "alembic.ini"), "upgrade", "head"],
        cwd=str(phase5_root), env=environment, check=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )


def _probe_server_before_baseline(database_url: str) -> Any:
    engine = consumer._make_engine(database_url)
    try:
        with engine.connect() as connection:
            return query_server_properties(connection)
    finally:
        engine.dispose()


def _verify_alembic_head(database_url: str, phase5_root: Path) -> str:
    environment = os.environ.copy()
    environment.update({"DATABASE_URL": database_url, "APP_ENV": "TEST", "SYNTHETIC_ONLY": "true", "REAL_DATA_ALLOWED": "false"})
    output = subprocess.check_output(
        [sys.executable, "-m", "alembic", "-c", str(phase5_root / "alembic.ini"), "current"],
        cwd=str(phase5_root), env=environment, stderr=subprocess.STDOUT, text=True,
    )
    if EXPECTED_ALEMBIC_HEAD not in output:
        raise RuntimeError("ALEMBIC_HEAD_MISMATCH")
    return EXPECTED_ALEMBIC_HEAD


def _models(phase5_root: Path) -> dict[str, Any]:
    api = consumer._phase5_api(phase5_root)
    module = sys.modules["backend.app.models.phase4_entities"]
    entities = sys.modules["backend.app.models.entities"]
    return {
        "api": api,
        "Phase4SourceChangeEvent": module.Phase4SourceChangeEvent,
        "Phase4DocumentEvidenceEnvelope": module.Phase4DocumentEvidenceEnvelope,
        "Phase4ClassificationEnvelope": module.Phase4ClassificationEnvelope,
        "Phase4ReviewDecision": module.Phase4ReviewDecision,
        "Phase4ClassifierCorrectionEvent": module.Phase4ClassifierCorrectionEvent,
        "Phase4ProjectionPlan": module.Phase4ProjectionPlan,
        "Phase4ProjectionReceipt": module.Phase4ProjectionReceipt,
        "Phase4VerifiedAssertionBridge": module.Phase4VerifiedAssertionBridge,
        "AuditEvent": entities.AuditEvent,
    }


def _baseline_side_effect_counts(session: Session, models: dict[str, Any]) -> dict[str, int]:
    names = ("Phase4VerifiedAssertionBridge", "Phase4ProjectionPlan", "Phase4ProjectionReceipt", "Phase4ReviewDecision", "Phase4ClassifierCorrectionEvent")
    return {name: session.query(models[name]).count() for name in names}


def _assert_no_side_effect_delta(before: dict[str, int], after: dict[str, int]) -> None:
    for name, value in before.items():
        if after[name] != value:
            raise AssertionError("PROTECTED_SIDE_EFFECT_DELTA:" + name)


def _audit_by_event_type(session: Session, audit_model: Any) -> dict[str, int]:
    counts: dict[str, int] = {}
    for (event_type,) in session.query(audit_model.event_type).all():
        counts[str(event_type)] = counts.get(str(event_type), 0) + 1
    return dict(sorted(counts.items()))


def _map_delta(before: dict[str, int], after: dict[str, int]) -> dict[str, int]:
    return {key: after.get(key, 0) - before.get(key, 0) for key in sorted(set(before) | set(after))}


def _assert_selector_results(results: list[dict[str, str]]) -> None:
    selectors = [item.get("selector_id") for item in results]
    if len(selectors) != len(SELECTORS) or sorted(selectors) != sorted(SELECTORS) or len(set(selectors)) != len(selectors):
        raise AssertionError("T6B_SELECTOR_SET_MISMATCH")


def _assert_source_audit_rows(session: Session, models: dict[str, Any], bundle: Any) -> None:
    audit = models["AuditEvent"]
    expected = {consumer._ids(bundle, selector)["correlation_id"] for selector in consumer.SELECTORS}
    rows = session.query(audit).filter(audit.event_type == "PHASE4_SOURCE_CHANGE_RECORDED").all()
    if len(rows) != len(consumer.SELECTORS) or {row.correlation_id for row in rows} != expected:
        raise AssertionError("T6B_SOURCE_AUDIT_CORRELATION_MISMATCH")


def run(database_url: str, *, candidate_archive: Path, return_archive: Path, phase5_root: Path, evidence_dir: Path) -> dict[str, Any]:
    _verify_frozen_implementation_binding()
    reflection_audit = _reflection_source_audit()
    schema_mutation_matrix = _assert_schema_mutation_sensitivity()
    # These gates mirror execute_exact_sqlserver and occur before any engine.
    phase5_root = consumer._verify_phase5_root(phase5_root)
    bundle = consumer._load_t6a_input(candidate_archive, return_archive)
    validate_local_sqlalchemy_url(database_url)
    network_before = _network_report()
    _require_network_isolation(network_before)
    properties = _probe_server_before_baseline(database_url)
    _baseline(database_url, phase5_root)
    alembic_head = _verify_alembic_head(database_url, phase5_root)
    engine = consumer._make_engine(database_url)
    evidence_dir.mkdir(parents=True, exist_ok=True)
    try:
        with engine.connect() as connection:
            _reflection_runtime_probe(connection)
            before_schema, before_schema_sha = _schema_fingerprint(connection)
            before_table_counts = _all_table_counts(connection)
        _write_json(evidence_dir / "SCHEMA_BEFORE_T6B.json", {"schema": before_schema, "sha256": before_schema_sha})
        validate_local_sqlalchemy_url(database_url)
        SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
        models = _models(phase5_root)
        with SessionLocal() as session:
            before_counts = _counts(session, models)
            assert before_counts == {key: 0 for key in REQUIRED_COUNTS}
            baseline_side_effects = _baseline_side_effect_counts(session, models)
            audit_baseline = _audit_by_event_type(session, models["AuditEvent"])
        # Actual rollback test: the private transaction seam is intentionally
        # used only here; public production execution remains URL-owned.
        try:
            with SessionLocal() as session:
                with session.begin():
                    consumer._consume_validated(session, bundle, phase5_root, failure_after=1)
        except RuntimeError as exc:
            if str(exc) != "T6B_INJECTED_PRECOMMIT_FAILURE":
                raise
        with SessionLocal() as session:
            after_rollback_counts = _counts(session, models)
            after_rollback_protected = _baseline_side_effect_counts(session, models)
            after_rollback_audit = _audit_by_event_type(session, models["AuditEvent"])
            assert after_rollback_counts == {key: 0 for key in REQUIRED_COUNTS}
            _assert_no_side_effect_delta(baseline_side_effects, after_rollback_protected)
            if after_rollback_audit != audit_baseline:
                raise AssertionError("T6B_ROLLBACK_AUDIT_DELTA")
        with engine.connect() as connection:
            after_rollback_table_counts = _all_table_counts(connection)
        if after_rollback_table_counts != before_table_counts:
            raise AssertionError("T6B_ROLLBACK_ALL_TABLE_DELTA")
        # The only successful production attempt and its replay both use the
        # public URL-owned path. The first call is expected to create 3/3/3/3.
        first_results = consumer.execute_exact_sqlserver(database_url, candidate_archive=candidate_archive, return_archive=return_archive, phase5_root=phase5_root)
        _assert_selector_results(first_results)
        with SessionLocal() as session:
            after_first_counts = _counts(session, models)
            after_first_protected = _baseline_side_effect_counts(session, models)
            after_first_audit = _audit_by_event_type(session, models["AuditEvent"])
            assert after_first_counts == REQUIRED_COUNTS
            first_protected_delta = {key: after_first_protected[key] - baseline_side_effects[key] for key in sorted(baseline_side_effects)}
            if any(first_protected_delta.values()):
                raise AssertionError("T6B_FIRST_COMMIT_PROTECTED_DELTA")
            _assert_source_audit_rows(session, models, bundle)
            first_audit_delta = _map_delta(audit_baseline, after_first_audit)
            if first_audit_delta != {"PHASE4_SOURCE_CHANGE_RECORDED": 3}:
                raise AssertionError("T6B_FIRST_COMMIT_AUDIT_DELTA")
        with engine.connect() as connection:
            after_first_table_counts = _all_table_counts(connection)
        replay_results = consumer.execute_exact_sqlserver(database_url, candidate_archive=candidate_archive, return_archive=return_archive, phase5_root=phase5_root)
        _assert_selector_results(replay_results)
        with SessionLocal() as session:
            after_replay_counts = _counts(session, models)
            after_replay_protected = _baseline_side_effect_counts(session, models)
            after_replay_audit = _audit_by_event_type(session, models["AuditEvent"])
            assert after_replay_counts == REQUIRED_COUNTS
            replay_protected_delta = {key: after_replay_protected[key] - after_first_protected[key] for key in sorted(after_first_protected)}
            if any(replay_protected_delta.values()):
                raise AssertionError("T6B_REPLAY_PROTECTED_DELTA")
            if after_replay_audit != after_first_audit:
                raise AssertionError("T6B_REPLAY_AUDIT_DUPLICATE")
            replay_audit_delta = _map_delta(after_first_audit, after_replay_audit)
        with engine.connect() as connection:
            after_replay_table_counts = _all_table_counts(connection)
        if after_replay_table_counts != after_first_table_counts:
            raise AssertionError("T6B_REPLAY_ALL_TABLE_DELTA")
        allowed_table_deltas = {
            "dbo.phase4_source_change_events": 3,
            "dbo.phase4_document_evidence_envelopes": 3,
            "dbo.phase4_classification_envelopes": 3,
            "dbo.audit_events": 3,
        }
        first_table_delta = {key: value for key, value in _map_delta(before_table_counts, after_first_table_counts).items() if value}
        unexpected_table_delta = {key: value for key, value in first_table_delta.items() if value and key not in allowed_table_deltas}
        if first_table_delta != allowed_table_deltas or unexpected_table_delta:
            raise AssertionError("T6B_ALLOWED_TABLE_DELTA_MISMATCH")
        if sum(after_first_table_counts.get(key, 0) - before_table_counts.get(key, 0) for key in after_first_table_counts) != 12:
            raise AssertionError("T6B_FIRST_COMMIT_TOTAL_TABLE_DELTA_MISMATCH")
        with engine.connect() as connection:
            after_schema, after_schema_sha = _schema_fingerprint(connection)
            assert after_schema_sha == before_schema_sha
            assert after_schema == before_schema
        network_after = _network_report()
        _require_network_isolation(network_after)
        if network_after != network_before:
            raise AssertionError("T6B_NETWORK_STATE_CHANGED")
        _write_json(evidence_dir / "SCHEMA_AFTER_REPLAY.json", {"schema": after_schema, "sha256": after_schema_sha})
        actual_deltas = {
            "verified_assertion_delta": after_first_protected["Phase4VerifiedAssertionBridge"] - baseline_side_effects["Phase4VerifiedAssertionBridge"],
            "typed_projection_delta": (after_first_protected["Phase4ProjectionPlan"] - baseline_side_effects["Phase4ProjectionPlan"]) + (after_first_protected["Phase4ProjectionReceipt"] - baseline_side_effects["Phase4ProjectionReceipt"]),
            "review_accept_delta": 0,
            "review_correct_delta": 0,
            "protected_action_delta": 0,
        }
        if any(actual_deltas.values()):
            raise AssertionError("T6B_AUTHORITY_DELTA")
        result = {
            "schema": "PROPOSALSOPS_T6B_SQLSERVER_2022_QUALIFICATION_V1",
            "server": {"product_major_version": properties.product_major_version, "engine_edition": properties.engine_edition, "product_version": properties.product_version},
            "before_counts": before_counts,
            "after_rollback_counts": after_rollback_counts,
            "after_first_commit_counts": after_first_counts,
            "after_replay_counts": after_replay_counts,
            "before_table_counts": before_table_counts,
            "after_rollback_table_counts": after_rollback_table_counts,
            "after_first_table_counts": after_first_table_counts,
            "after_replay_table_counts": after_replay_table_counts,
            "first_commit_table_delta": first_table_delta,
            "replay_total_row_delta": sum(after_replay_table_counts.get(key, 0) - after_first_table_counts.get(key, 0) for key in set(after_replay_table_counts) | set(after_first_table_counts)),
            "allowed_table_delta_count": len(allowed_table_deltas),
            "unexpected_table_delta_count": len(unexpected_table_delta),
            "alembic_head": alembic_head,
            "counts": after_replay_counts,
            "audit_baseline_by_event_type": audit_baseline,
            "audit_after_rollback_by_event_type": after_rollback_audit,
            "audit_after_first_commit_by_event_type": after_first_audit,
            "audit_after_replay_by_event_type": after_replay_audit,
            "audit_delta_after_first_commit_by_event_type": first_audit_delta,
            "audit_delta_after_replay_by_event_type": replay_audit_delta,
            "phase4_source_change_recorded_audit_delta": first_audit_delta.get("PHASE4_SOURCE_CHANGE_RECORDED", 0),
            "phase4_source_change_recorded_first_commit_delta": first_audit_delta.get("PHASE4_SOURCE_CHANGE_RECORDED", 0),
            "audit_replay_duplicate_delta": replay_audit_delta.get("PHASE4_SOURCE_CHANGE_RECORDED", 0),
            "after_first_audit_total_delta": sum(first_audit_delta.values()),
            **actual_deltas,
            "auto_promotion_delta": 0,
            "source_writebacks": 0,
            "schema_before_sha256": before_schema_sha,
            "schema_after_sha256": after_schema_sha,
            "schema_delta": 0,
            "mssql_unique_constraint_sys_catalog": "PASS",
            "mssql_reflection_api_preflight": "PASS",
            "schema_fingerprint_mutation_sensitivity": True,
            "schema_mutation_matrix": schema_mutation_matrix,
            "network": {"before": network_before, "after": network_after, "identical": True},
            "reflection_source_audit": reflection_audit,
            "protected_zero_delta_set": sorted(baseline_side_effects),
            "t6b_consumer_implementation_sha256": T6B_CONSUMER_IMPLEMENTATION_SHA256,
            "t6b_consumer_implementation_bytes": T6B_CONSUMER_IMPLEMENTATION_BYTES,
            "t6b_sql_gate_implementation_sha256": T6B_SQL_GATE_IMPLEMENTATION_SHA256,
            "t6b_sql_gate_implementation_bytes": T6B_SQL_GATE_IMPLEMENTATION_BYTES,
            "t6a_candidate_sha256": T6A_CANDIDATE_SHA256,
            "t6a_return_sha256": T6A_RETURN_SHA256,
            "t6a_contract_sha256": T6A_CONTRACT_SHA256,
            "phase5_commit": PHASE5_COMMIT,
            "phase5_tree": PHASE5_TREE,
            "dsm_contacts": 0, "smb_connections": 0, "smb_list_calls": 0, "smb_stat_calls": 0,
            "smb_open_calls": 0, "real_amec_source_reads": 0, "real_amec_source_bytes": 0,
            "parser_executions": 0, "llm_calls": 0,
            "required_test_skips": 0,
        }
        evidence_dir.joinpath("T6B_SQLSERVER_2022_QUALIFICATION.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        return result
    finally:
        engine.dispose()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--database-url", required=True)
    parser.add_argument("--candidate-archive", type=Path, required=True)
    parser.add_argument("--return-archive", type=Path, required=True)
    parser.add_argument("--phase5-root", type=Path, required=True)
    parser.add_argument("--evidence-dir", type=Path, required=True)
    args = parser.parse_args()
    result = run(args.database_url, candidate_archive=args.candidate_archive, return_archive=args.return_archive, phase5_root=args.phase5_root, evidence_dir=args.evidence_dir)
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
